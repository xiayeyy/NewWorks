using UnityEngine;
using UnityEditor;

using System;
using System.Collections.Generic;

public class MyPrefabricator : AssetBundleGraph.PrefabricatorBase {
	public override void ValidateCanCreatePrefab (string nodeName, string nodeId, string groupKey, List<AssetBundleGraph.DepreacatedAssetInfo> sources, string recommendedPrefabOutputDir, Func<string, string> Prefabricate) {
		// Test and see if Prefab can be created
		// use Prefabricate deledate to create prefab.
	}

	public override void CreatePrefab (string nodeName, string nodeId, string groupKey, List<AssetBundleGraph.DepreacatedAssetInfo> source, string recommendedPrefabOutputDir, Func<GameObject, string, bool, string> Prefabricate) {
		// use Prefabricate deledate to create prefab.
	}
}
