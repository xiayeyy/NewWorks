using System;
using System.Collections.Generic;

namespace AssetBundleGraph {
	public class AssetBundleGraphData {
		public string lastModified;
		public List<object> nodes;
		public List<object> connections;
	}
}

