/Applications/Unity/Unity.app/Contents/MacOS/Unity -batchmode -quit -projectPath $(pwd)\
	-executeMethod AssetBundleGraph.AssetBundleGraphEditorWindow.BuildFromCommandline